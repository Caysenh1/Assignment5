a = float(input("Enter value for a: "))
b = float(input("Enter value for b: "))
c = float(input("Enter value for c: "))
total = b**2-4*a*c
print(round(total, 2))
