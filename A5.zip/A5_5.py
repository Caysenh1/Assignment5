base = float(input("Enter a base: "))
Height = float(input("Enter a Height: "))
calc = base*Height/2
print(base)
print(Height)
print(calc)
