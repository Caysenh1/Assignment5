num1 = int(input("Enter a number: "))
calc = num1 + 10.0
print(calc)
