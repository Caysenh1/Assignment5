name = input("Enter your name: ")
password = input("Enter your password: ")
print(name)
print(password)
