hours = float(input("Enter a time (hours): "))
minutes = hours*60
seconds = hours*3600
print(minutes,seconds)
