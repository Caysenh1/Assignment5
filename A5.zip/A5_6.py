costTV = 3999.00
Tax = 1.11
EHF = 7
Totalcost = costTV*Tax+EHF
print("Total TV cost:", round(Totalcost, 2))
