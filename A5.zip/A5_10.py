a = float(input("Enter value for a: "))
b = float(input("Enter value for a: "))
c = float(input("Enter value for c: "))
x = (-b+(b**2-4*a*c)**0.5)/2*a
x2 = (-b-(b**2-4*a*c)**0.5)/2*a
print(round(x,2))
print(round(x2,2))
