num1 = float(input("Enter num1: "))
num2 = float(input("Enter num2: "))
num1 = num1+2.5
num2 = num2*2
calc = num1+num2
print(calc)


